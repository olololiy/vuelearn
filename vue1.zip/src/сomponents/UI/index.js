import MyButton from "@/сomponents/UI/MyButton";
import MyInput from "@/сomponents/UI/MyInput";

export default [
    MyButton,
    MyInput
]