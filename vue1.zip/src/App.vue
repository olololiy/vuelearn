/* eslint-disable */
<template>

  <div class="app">
    <post-form @create="createPost"/>
    <post-list :posts="posts"/>
  </div>

</template>

<script>
import postList from "@/сomponents/PostList";
import postForm from "@/сomponents/PostForm";

export default { // в скрипте по дефолту экспортируется объект
  components: {
    postList, postForm
  },
  data() {   //поле
    return {
      posts: [//модель
        {id: 1, title: 'JS', body: 'описание'},
        {id: 2, title: 'JS1', body: 'описание1'},
        {id: 3, title: 'JS2', body: 'описание2'},
      ],
    }
  },
  methods: { //поле
    createPost(post) { //брал экземпляр из текущей модели
      this.posts.push(post)
    }

  }

}
</script>

<style scoped>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}


</style>